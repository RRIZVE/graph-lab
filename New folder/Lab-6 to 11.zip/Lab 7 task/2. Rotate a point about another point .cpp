/*C graphics program to draw .*/
#include<bits/stdc++.h>
#include <graphics.h>
using namespace std;




typedef complex<double> point;
#define x real()
#define y imag()

#define PI M_PI

void displayPoint(point P)
{
    cout << "(" << P.x << ", " << P.y << ")" << endl;
}

point rotate(point P, point Q, double theta)
{
    return (P-Q) * polar(1.0, theta) + Q;
}
main()
{
    int gd = DETECT, gm;

    //init graphics
    initgraph(&gd, &gm, (char*) "");
double a,b,c,d;

    cout<<"Enter point P => ";
    cin>>a>>b;
    cout<<"\nEnter point Q => ";
    cin>>c>>d;
      point P(a, b);
    point Q(c, d);

line(a,b,c,d);
    double theta = PI/2;

    point P_rotated = rotate(P, Q, theta);
    cout << "Point P on rotating 90 degrees anti-clockwise about Q becomes:";
    cout << "\nP_rotated";

    displayPoint(P_rotated);
putpixel(floor(theta),floor(P_rotated),GREEN);

    getch();
    closegraph();
    return 0;
}




/*C graphics program to draw .*/
#include<bits/stdc++.h>
#include <graphics.h>
using namespace std;
main()
{
    int gd = DETECT, gm;
   int x1,y1,x2,y2;
    double s,c, angle;
    //init graphics
    initgraph(&gd, &gm, (char*) "");


 setcolor(GREEN);
    printf("Enter your coordinates of line: ");

    cin>>x1>>y1>>x2>>y2;

  setbkcolor(WHITE);
    line(x1,y1,x2,y2);

    setbkcolor(BLACK);
    printf("Enter rotation angle: ");

   cin>>angle;
    setbkcolor(WHITE);
    c = cos(angle *M_PI/180);
    s = sin(angle *M_PI/180);
    x1 = floor(x1 * c + y1 * s);
    y1 = floor(-x1 * s + y1 * c);
    x2 = floor(x2 * c + y2 * s);
    y2 = floor(-x2 * s + y2 * c);
    cleardevice();
    line(x1, y1 ,x2, y2);

  getch();
    closegraph();
    return 0;
}


/*C graphics program to draw .*/
#include<bits/stdc++.h>
#include <graphics.h>
using namespace std;
main()
{
    int gd = DETECT, gm;


    initgraph(&gd, &gm, (char*) "");

double angle,x,y,x1,y1;

cout<<"Enter the angle=>";cin>>angle;
cout<<"\nEnter the x and y: ";
cin>>x>>y;
x1 = x*cos(angle) - y*sin(angle);

y1=y*cos(angle)+  x*sin(angle);
putpixel(x,y,RED);
putpixel(x1,y1,GREEN);
setcolor(GREEN);
line(x,y,x1,y1);
    getch();
    closegraph();
    return 0;
}


